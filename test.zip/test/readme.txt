Run with C=0.012


1. Run 3 times (for each of the 3 network files):
change the current "network_x" file to "network" and run with C = 0.005.
Write the scores in the form.
2. Write which one is the true network in the form (there shpould be ~15 points difference in the score).
3. For the true PPI network alone:
Take the best_clustering.xgmml and using cytoscape and BiNGO infer the function of each cluster and write them in the form.
See detailed explanations in the project specification appendix B.

For the wrong networks run may take up to 20 mins, for the right network it should be under 15 mins.
Might be much faster, depending on the load on the servers. See FAQ.txt for other servers to use for speeding running time.
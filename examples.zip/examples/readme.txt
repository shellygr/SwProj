Run with:

Cluster example1_C=0/ example1_C=0/ 0
Cluster example1_C=0.323_ONE_OPTIMAL_SOLUTION/ example1_C=0.323_ONE_OPTIMAL_SOLUTION/ 0.323
Cluster example1_C=1/ example1_C=1/ 1
Cluster example2_C=1/ example2_C=1/ 1
Cluster example3_C=0.02/ example3_C=0.02/ 0.02